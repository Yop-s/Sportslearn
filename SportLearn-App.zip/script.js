// Minimal boot script + fixes
let deferredPrompt=null;
window.addEventListener('beforeinstallprompt',(e)=>{
  e.preventDefault(); deferredPrompt=e;
  const btn=document.getElementById('installBtn');
  if(btn){btn.style.display='inline-block'; btn.onclick=async()=>{
    if(!deferredPrompt) return;
    deferredPrompt.prompt();
    await deferredPrompt.userChoice;
    deferredPrompt=null;
  }}
});

function playVideo(url){ window.open(url,'_blank'); }
function startLearning(){ alert('Progress belajar dimulai!'); }
function addToFavorites(){ alert('Ditambahkan ke favorit'); }

// Dummy stats init
document.addEventListener('DOMContentLoaded',()=>{
  const ids=['completedSports','learningHours','achievements','streak'];
  ids.forEach(id=>{const el=document.getElementById(id); if(el) el.textContent=0;});
});
